package com.example.demo.constant;

public class Constant {
}
